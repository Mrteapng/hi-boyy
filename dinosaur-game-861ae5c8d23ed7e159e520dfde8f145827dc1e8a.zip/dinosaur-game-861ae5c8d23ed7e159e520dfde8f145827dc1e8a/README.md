# dinosaur-game
T-Rex runner online

<img src="https://raw.githubusercontent.com/wayou/t-rex-runner/gh-pages/assets/screenshot.gif">

The best Game Ever! A cute dinosaur run over the cacti and pterodactels.
